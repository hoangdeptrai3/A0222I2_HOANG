package service;

import model.LoaiMatBang;

import java.util.List;

public interface ILoaiMatBangService {
    List<LoaiMatBang> findAll();

}
